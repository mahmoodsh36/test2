python -m venv C:\venv
. C:\venv\Scripts\activate.ps1
pip install tqdm flask pynput psutil paramiko rich requests
python C:\main.py